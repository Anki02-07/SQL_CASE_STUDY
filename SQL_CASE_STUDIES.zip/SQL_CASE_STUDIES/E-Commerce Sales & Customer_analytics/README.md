📊 Project 01 — Olist E-Commerce Analysis

Tools: Microsoft SQL Server, SQL, SQL Server Management Studio (SSMS)
Dataset: Brazilian E-Commerce Public Dataset by Olist
Project Type: SQL Business Intelligence & Data Analytics
Database: Microsoft SQL Server

1. 📌 Project Overview

This project analyzes an e-commerce dataset using SQL Server to understand sales performance, customer behavior, payment patterns, delivery performance, product performance, seller performance, and customer satisfaction.

The objective is to transform raw e-commerce transaction data into meaningful business insights using SQL.

The analysis focuses on:

Sales and revenue performance
Monthly and yearly sales trends
Product category performance
Product sales volume
Seller revenue
Geographic sales distribution
Average Order Value (AOV)
Payment methods
Delivery performance
Customer ratings
Late delivery and customer satisfaction
High-value customers
Order cancellations
Categories with high sales but lower ratings

The project demonstrates practical SQL skills including multi-table JOINs, aggregation, GROUP BY, HAVING, CASE WHEN, CTEs, subqueries, date functions, window functions, ranking, filtering, and NULL handling. These are among the SQL skills specified in the assessment.

2. 🎯 Business Problem

An e-commerce company wants to better understand its sales and customer data in order to support data-driven business decisions.

The company needs answers to questions such as:

How much revenue is being generated?
How are sales changing over time?
Which product categories generate the most revenue?
Which products have the highest sales volume?
Which sellers generate the most revenue?
Which states and cities contribute the most sales?
What is the average order value?
Which payment methods are most frequently used?
How long do customers typically wait for delivery?
Are late deliveries associated with lower customer ratings?
Which customers spend the most?
What percentage of orders are cancelled?
Which categories combine high sales with comparatively lower customer ratings?

The purpose of this analysis is to provide a structured SQL-based view of the business and identify areas that can be investigated further.

3. 📂 Dataset

The project uses the Brazilian E-Commerce Public Dataset by Olist.

The database contains multiple related tables representing different parts of the e-commerce process.

Main tables used
Table	Purpose
olist_orders_dataset	Order information and order status
olist_order_payments_dataset	Payment information and transaction values
olist_order_reviews_dataset	Customer reviews and ratings
olist_customers_dataset	Customer information and geographic details
olist_order_items_dataset	Product items included in orders
olist_products_dataset	Product information
olist_sellers_dataset	Seller information
product_category_name_translation	Product category translation
4. 🗄️ Database Schema

The main relationships used in the analysis are:

                                                 ┌─────────────────────────┐
                         │   CUSTOMERS              │
                         │ olist_customers_dataset │
                         └────────────┬────────────┘
                                      │
                                customer_id
                                      │
                                      ▼
                         ┌─────────────────────────┐
                         │   ORDERS                │
                         │ olist_orders_dataset    │
                         └───────┬─────────┬───────┘
                                 │         │
                             order_id    order_id
                                 │         │
                  ┌──────────────┘         └──────────────┐
                  ▼                                       ▼
       ┌─────────────────────┐                 ┌──────────────────────┐
       │ ORDER PAYMENTS      │                 │ ORDER REVIEWS        │
       │ payment_value       │                 │ review_score         │
       │ payment_type        │                 │ review comments      │
       └─────────────────────┘                 └──────────────────────┘

                                 │
                              order_id
                                 │
                                 ▼
                       ┌──────────────────────┐
                       │ ORDER ITEMS          │
                       │ product_id           │
                       │ seller_id            │
                       │ price                │
                       └───────┬───────┬──────┘
                               │       │
                         product_id  seller_id
                               │       │
                 ┌─────────────┘       └──────────────┐
                 ▼                                    ▼
       ┌────────────────────┐              ┌────────────────────┐
       │ PRODUCTS           │              │ SELLERS            │
       │ product_category   │              │ seller_city        │
       │ product_id         │              │ seller_state       │
       └─────────┬──────────┘              └────────────────────┘
                 │
                 │ category
                 ▼
       ┌─────────────────────────────┐
       │ CATEGORY TRANSLATION        │
       │ Portuguese → English       │
       └─────────────────────────────┘

🧠 SQL Concepts Used

This project demonstrates the following SQL concepts required by the assessment.

Basic SQL
SELECT
WHERE
ORDER BY
GROUP BY
DISTINCT
Aggregate Functions
COUNT()
SUM()
AVG()
ROUND()
Conditional Logic
CASE WHEN
Joins
INNER JOIN
LEFT JOIN
Multiple-table JOINs
Advanced SQL
CTEs using WITH
Subqueries
Window functions
RANK()
SUM() OVER()
HAVING
Date Functions
YEAR()
MONTH()
DATENAME()
DATEDIFF()
TRY_CONVERT()
Data Quality / NULL Handling
TRY_CONVERT()
IS NULL
IS NOT NULL
COALESCE()