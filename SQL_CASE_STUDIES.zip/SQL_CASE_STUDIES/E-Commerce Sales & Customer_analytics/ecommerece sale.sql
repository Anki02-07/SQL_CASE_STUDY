﻿use OlistECommerce
/*====================================================================
 PROJECT 01
 E-COMMERCE SALES & CUSTOMER ANALYTICS
 Dataset: Brazilian E-Commerce Public Dataset by Olist

 Database Platform: Microsoft SQL Server

 IMPORTANT NOTES:
 1. The imported column names contain double quotation marks.
    Example:
        ["order_id"]
    instead of:
        order_id

 2. Several columns were imported as VARCHAR.
    Therefore TRY_CONVERT() is used for:
       - Dates
       - Numeric values
       - Review scores
       - Payment installments

 3. The current database does NOT show:
       dbo.olist_order_items_dataset

    Therefore product/category/seller analysis requiring the
    order_items bridge cannot be executed correctly until that
    table is imported.

====================================================================*/


/*====================================================================
 0. DATABASE SELECTION
 ====================================================================*/

-- Replace YourDatabaseName with your actual database name.

-- USE YourDatabaseName;
-- GO


/*====================================================================
 1. DATABASE / TABLE CHECK
 ====================================================================*/

-- Display all tables in the dbo schema.

SELECT
    TABLE_SCHEMA,
    TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'dbo'
ORDER BY TABLE_NAME;


/*====================================================================
 2. CHECK COLUMN STRUCTURE
 ====================================================================*/

-- Display all columns and their data types.

SELECT
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo'
ORDER BY
    TABLE_NAME,
    ORDINAL_POSITION;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 1
 What is the total number of orders and total revenue?
 ====================================================================*/


/*--------------------------------------------------------------------
 Q1A. TOTAL NUMBER OF ORDERS
 --------------------------------------------------------------------*/

SELECT
    COUNT(DISTINCT ["order_id"]) AS total_orders
FROM dbo.olist_orders_dataset;


/*--------------------------------------------------------------------
 Q1B. TOTAL REVENUE
 --------------------------------------------------------------------*/

SELECT
    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                ["payment_value"]
            )
        ),
        2
    ) AS total_revenue
FROM dbo.olist_order_payments_dataset;


/*--------------------------------------------------------------------
 Q1C. TOTAL ORDERS + TOTAL REVENUE
 --------------------------------------------------------------------*/

SELECT

    (
        SELECT
            COUNT(DISTINCT ["order_id"])
        FROM dbo.olist_orders_dataset
    ) AS total_orders,

    (
        SELECT
            ROUND(
                SUM(
                    TRY_CONVERT(
                        DECIMAL(18,2),
                        ["payment_value"]
                    )
                ),
                2
            )
        FROM dbo.olist_order_payments_dataset
    ) AS total_revenue;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 2
 What are the monthly and yearly sales trends?
 ====================================================================*/


/*--------------------------------------------------------------------
 Q2A. YEARLY SALES TREND
 --------------------------------------------------------------------*/

SELECT

    YEAR(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ) AS sales_year,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_orders_dataset AS o

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY

    YEAR(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    )

ORDER BY
    sales_year;


/*--------------------------------------------------------------------
 Q2B. MONTHLY SALES TREND
 --------------------------------------------------------------------*/

SELECT

    YEAR(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ) AS sales_year,

    MONTH(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ) AS sales_month,

    DATENAME(
        MONTH,
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ) AS month_name,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_orders_dataset AS o

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY

    YEAR(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ),

    MONTH(
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    ),

    DATENAME(
        MONTH,
        TRY_CONVERT(
            DATETIME,
            o.["order_purchase_timestamp"]
        )
    )

ORDER BY
    sales_year,
    sales_month;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 3
 Which product categories generate the highest revenue?

 STATUS:
 Requires dbo.olist_order_items_dataset.

 The order_items table connects:
    order_id
    product_id
    seller_id

 Without it, product/category revenue cannot be attributed correctly.

 The query is provided below for use after importing the table.
 ====================================================================*/
/*==============================================================
 Q3 - TOP 10 PRODUCT CATEGORIES BY REVENUE
 ==============================================================*/

SELECT TOP 10

    p.["product_category_name"] AS category_name,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                oi.["price"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_order_items_dataset AS oi

INNER JOIN dbo.olist_products_dataset AS p
    ON oi.["product_id"] = p.["product_id"]

GROUP BY
    p.["product_category_name"]

ORDER BY
    total_revenue DESC;



/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 4
 Which products have the highest sales volume?

 STATUS:
 Requires dbo.olist_order_items_dataset.
 ====================================================================*/

 SELECT TOP 10
    oi.["product_id"] AS product_id,
    COALESCE(
        t.product_category_name_english,
        p.["product_category_name"]
    ) AS category_name,
    COUNT(*) AS units_sold,
    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                oi.["price"]
            )
        ),
        2
    ) AS product_revenue
FROM dbo.olist_order_items_dataset AS oi
INNER JOIN dbo.olist_products_dataset AS p
    ON oi.["product_id"] = p.["product_id"]
LEFT JOIN dbo.product_category_name_translation AS t
    ON p.["product_category_name"] = t.product_category_name -- No quotes for table t
GROUP BY
    oi.["product_id"],
    COALESCE(
        t.product_category_name_english,
        p.["product_category_name"]
    )
ORDER BY product_revenue DESC;



  


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 5
 Which sellers generate the highest revenue?

 STATUS:
 Requires dbo.olist_order_items_dataset.
 ====================================================================*/



SELECT TOP 10

    oi.["seller_id"] AS seller_id,

    s.["seller_city"] AS seller_city,

    s.["seller_state"] AS seller_state,

    COUNT(*) AS items_sold,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                oi.["price"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_order_items_dataset AS oi

INNER JOIN dbo.olist_sellers_dataset AS s
    ON oi.["seller_id"] = s.["seller_id"]

GROUP BY

    oi.["seller_id"],
    s.["seller_city"],
    s.["seller_state"]

ORDER BY
    total_revenue DESC;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 6
 Which states/cities contribute the most sales?
 ====================================================================*/


/*--------------------------------------------------------------------
 Q6A. SALES BY STATE
 --------------------------------------------------------------------*/

SELECT

    c.["customer_state"] AS customer_state,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_customers_dataset AS c

INNER JOIN dbo.olist_orders_dataset AS o
    ON c.["customer_id"] = o.["customer_id"]

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY
    c.["customer_state"]

ORDER BY
    total_revenue DESC;


/*--------------------------------------------------------------------
 Q6B. TOP 10 STATES
 --------------------------------------------------------------------*/

SELECT TOP 10

    c.["customer_state"] AS customer_state,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_customers_dataset AS c

INNER JOIN dbo.olist_orders_dataset AS o
    ON c.["customer_id"] = o.["customer_id"]

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY
    c.["customer_state"]

ORDER BY
    total_revenue DESC;


/*--------------------------------------------------------------------
 Q6C. TOP 10 CITIES
 --------------------------------------------------------------------*/

SELECT TOP 10

    c.["customer_city"] AS customer_city,

    c.["customer_state"] AS customer_state,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_revenue

FROM dbo.olist_customers_dataset AS c

INNER JOIN dbo.olist_orders_dataset AS o
    ON c.["customer_id"] = o.["customer_id"]

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY

    c.["customer_city"],
    c.["customer_state"]

ORDER BY
    total_revenue DESC;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 7
 What is the average order value?
 ====================================================================*/


WITH order_values AS
(
    SELECT

        ["order_id"] AS order_id,

        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                ["payment_value"]
            )
        ) AS order_value

    FROM dbo.olist_order_payments_dataset

    GROUP BY
        ["order_id"]
)

SELECT

    ROUND(
        AVG(order_value),
        2
    ) AS average_order_value

FROM order_values;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 8
 Which payment methods are most commonly used?
 ====================================================================*/


/*--------------------------------------------------------------------
 Q8A. PAYMENT METHOD FREQUENCY
 --------------------------------------------------------------------*/

SELECT

    ["payment_type"] AS payment_type,

    COUNT(*) AS payment_count

FROM dbo.olist_order_payments_dataset

GROUP BY
    ["payment_type"]

ORDER BY
    payment_count DESC;


/*--------------------------------------------------------------------
 Q8B. PAYMENT METHOD PERCENTAGE
 Uses a WINDOW FUNCTION.
 --------------------------------------------------------------------*/

WITH payment_summary AS
(
    SELECT

        ["payment_type"] AS payment_type,

        COUNT(*) AS payment_count

    FROM dbo.olist_order_payments_dataset

    GROUP BY
        ["payment_type"]
)

SELECT

    payment_type,

    payment_count,

    ROUND(
        payment_count * 100.0 /
        SUM(payment_count) OVER (),
        2
    ) AS percentage_of_payments

FROM payment_summary

ORDER BY
    payment_count DESC;


/*--------------------------------------------------------------------
 Q8C. PAYMENT INSTALLMENT ANALYSIS
 --------------------------------------------------------------------*/

SELECT

    TRY_CONVERT(
        INT,
        ["payment_installments"]
    ) AS installments,

    COUNT(*) AS payment_count,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                ["payment_value"]
            )
        ),
        2
    ) AS total_payment_value

FROM dbo.olist_order_payments_dataset

GROUP BY

    TRY_CONVERT(
        INT,
        ["payment_installments"]
    )

ORDER BY
    installments;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 9
 What is the average delivery time?
 ====================================================================*/


SELECT

    ROUND(

        AVG(

            CAST(

                DATEDIFF(

                    DAY,

                    TRY_CONVERT(
                        DATETIME,
                        ["order_purchase_timestamp"]
                    ),

                    TRY_CONVERT(
                        DATETIME,
                        ["order_delivered_customer_date"]
                    )

                ) AS FLOAT

            )

        ),

        2

    ) AS average_delivery_days

FROM dbo.olist_orders_dataset

WHERE

    TRY_CONVERT(
        DATETIME,
        ["order_delivered_customer_date"]
    ) IS NOT NULL;


/*====================================================================
 ADDITIONAL DELIVERY ANALYSIS
 On-Time vs Late Delivery
 ====================================================================*/


SELECT

    CASE

        WHEN
            TRY_CONVERT(
                DATETIME,
                ["order_delivered_customer_date"]
            )
            >
            TRY_CONVERT(
                DATETIME,
                ["order_estimated_delivery_date"]
            )
        THEN 'Late'

        WHEN
            TRY_CONVERT(
                DATETIME,
                ["order_delivered_customer_date"]
            )
            <=
            TRY_CONVERT(
                DATETIME,
                ["order_estimated_delivery_date"]
            )
        THEN 'On Time'

        ELSE 'Unknown'

    END AS delivery_status,

    COUNT(*) AS number_of_orders

FROM dbo.olist_orders_dataset

GROUP BY

    CASE

        WHEN
            TRY_CONVERT(
                DATETIME,
                ["order_delivered_customer_date"]
            )
            >
            TRY_CONVERT(
                DATETIME,
                ["order_estimated_delivery_date"]
            )
        THEN 'Late'

        WHEN
            TRY_CONVERT(
                DATETIME,
                ["order_delivered_customer_date"]
            )
            <=
            TRY_CONVERT(
                DATETIME,
                ["order_estimated_delivery_date"]
            )
        THEN 'On Time'

        ELSE 'Unknown'

    END

ORDER BY
    number_of_orders DESC;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 10
 Which categories have the highest customer ratings?

 STATUS:
 Requires dbo.olist_order_items_dataset.

 Reason:
 Reviews connect to orders, but products connect to orders through
 order_items. Therefore category-level ratings require:

 orders
    ↓
 order_items
    ↓
 products
    ↓
 category
 ====================================================================*/
SELECT TOP 10
    COALESCE(
        t.product_category_name_english,
        REPLACE(p.["product_category_name"], '"', '')
    ) AS category_name,

    ROUND(
        AVG(
            TRY_CONVERT(
                FLOAT,
                REPLACE(r.["review_score"], '"', '')
            )
        ),
        2
    ) AS average_rating,

    COUNT(
        DISTINCT REPLACE(r.["review_id"], '"', '')
    ) AS number_of_reviews

FROM dbo.olist_order_items_dataset AS oi

INNER JOIN dbo.olist_products_dataset AS p
    ON REPLACE(oi.["product_id"], '"', '') = REPLACE(p.["product_id"], '"', '')

LEFT JOIN dbo.product_category_name_translation AS t
    ON REPLACE(p.["product_category_name"], '"', '') = t.product_category_name

LEFT JOIN dbo.olist_order_reviews_dataset AS r -- Changed to LEFT JOIN
    ON REPLACE(oi.["order_id"], '"', '') = REPLACE(r.["order_id"], '"', '')

GROUP BY
    COALESCE(
        t.product_category_name_english,
        REPLACE(p.["product_category_name"], '"', '')
    )

-- Removed the HAVING clause temporarily because number_of_reviews will be 0

ORDER BY
    number_of_reviews DESC; -- Changed sorting to see if rows populate








/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 11
 Are late deliveries associated with lower review scores?
 ====================================================================*/


SELECT
    CASE
        WHEN TRY_CONVERT(DATETIME, REPLACE(o.["order_delivered_customer_date"], '"', '')) > 
             TRY_CONVERT(DATETIME, REPLACE(o.["order_estimated_delivery_date"], '"', '')) 
        THEN 'Late'
        WHEN TRY_CONVERT(DATETIME, REPLACE(o.["order_delivered_customer_date"], '"', '')) <= 
             TRY_CONVERT(DATETIME, REPLACE(o.["order_estimated_delivery_date"], '"', '')) 
        THEN 'On Time'
        ELSE 'Unknown'
    END AS delivery_status,

    COUNT(DISTINCT REPLACE(o.["order_id"], '"', '')) AS total_orders

FROM dbo.olist_orders_dataset AS o

WHERE
    TRY_CONVERT(DATETIME, REPLACE(o.["order_delivered_customer_date"], '"', '')) IS NOT NULL
    AND TRY_CONVERT(DATETIME, REPLACE(o.["order_estimated_delivery_date"], '"', '')) IS NOT NULL

GROUP BY
    CASE
        WHEN TRY_CONVERT(DATETIME, REPLACE(o.["order_delivered_customer_date"], '"', '')) > 
             TRY_CONVERT(DATETIME, REPLACE(o.["order_estimated_delivery_date"], '"', '')) 
        THEN 'Late'
        WHEN TRY_CONVERT(DATETIME, REPLACE(o.["order_delivered_customer_date"], '"', '')) <= 
             TRY_CONVERT(DATETIME, REPLACE(o.["order_estimated_delivery_date"], '"', '')) 
        THEN 'On Time'
        ELSE 'Unknown'
    END
ORDER BY
    total_orders DESC;




/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 12
 Who are the top customers based on spending?
 ====================================================================*/


SELECT TOP 10

    c.["customer_unique_id"] AS customer_unique_id,

    c.["customer_city"] AS customer_city,

    c.["customer_state"] AS customer_state,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS total_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_spending

FROM dbo.olist_customers_dataset AS c

INNER JOIN dbo.olist_orders_dataset AS o
    ON c.["customer_id"] = o.["customer_id"]

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY

    c.["customer_unique_id"],
    c.["customer_city"],
    c.["customer_state"]

ORDER BY
    total_spending DESC;


/*--------------------------------------------------------------------
 ADDITIONAL:
 TOP REPEAT CUSTOMERS
 --------------------------------------------------------------------*/

SELECT TOP 10

    c.["customer_unique_id"] AS customer_unique_id,

    COUNT(
        DISTINCT o.["order_id"]
    ) AS number_of_orders,

    ROUND(
        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ),
        2
    ) AS total_spending

FROM dbo.olist_customers_dataset AS c

INNER JOIN dbo.olist_orders_dataset AS o
    ON c.["customer_id"] = o.["customer_id"]

INNER JOIN dbo.olist_order_payments_dataset AS p
    ON o.["order_id"] = p.["order_id"]

GROUP BY
    c.["customer_unique_id"]

HAVING
    COUNT(
        DISTINCT o.["order_id"]
    ) > 1

ORDER BY
    number_of_orders DESC;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 13
 What percentage of orders are cancelled?
 ====================================================================*/


SELECT

    COUNT(*) AS total_orders,

    SUM(

        CASE

            WHEN ["order_status"] = 'canceled'
            THEN 1

            ELSE 0

        END

    ) AS cancelled_orders,

    ROUND(

        SUM(

            CASE

                WHEN ["order_status"] = 'canceled'
                THEN 1

                ELSE 0

            END

        ) * 100.0 / COUNT(*),

        2

    ) AS cancellation_percentage

FROM dbo.olist_orders_dataset;


/*--------------------------------------------------------------------
 ORDER STATUS DISTRIBUTION
 --------------------------------------------------------------------*/

SELECT

    ["order_status"] AS order_status,

    COUNT(*) AS order_count,

    ROUND(

        COUNT(*) * 100.0 /
        SUM(COUNT(*)) OVER (),

        2

    ) AS percentage

FROM dbo.olist_orders_dataset

GROUP BY
    ["order_status"]

ORDER BY
    order_count DESC;


/*====================================================================
 PROJECT 01 - BUSINESS QUESTION 14
 Which categories have high sales but poor customer ratings?

 STATUS:
 Requires dbo.olist_order_items_dataset.

 This query uses:
    - CTE
    - JOIN
    - GROUP BY
    - Aggregate functions
    - Subqueries
 ====================================================================*/

WITH category_analysis AS
(
    SELECT
        COALESCE(
            t.product_category_name_english,
            REPLACE(p.["product_category_name"], '"', '')
        ) AS category_name,

        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                REPLACE(oi.["price"], '"', '')
            )
        ) AS total_sales,

        -- Returns NULL since there is no data in the reviews table
        AVG(
            TRY_CONVERT(
                FLOAT,
                REPLACE(r.["review_score"], '"', '')
            )
        ) AS average_rating

    FROM dbo.olist_order_items_dataset AS oi

    INNER JOIN dbo.olist_products_dataset AS p
        ON REPLACE(oi.["product_id"], '"', '') = REPLACE(p.["product_id"], '"', '')

    LEFT JOIN dbo.product_category_name_translation AS t
        ON REPLACE(p.["product_category_name"], '"', '') = t.product_category_name

    -- LEFT JOIN keeps your sales rows visible even with 0 reviews
    LEFT JOIN dbo.olist_order_reviews_dataset AS r
        ON REPLACE(oi.["order_id"], '"', '') = REPLACE(r.["order_id"], '"', '')

    GROUP BY
        COALESCE(
            t.product_category_name_english,
            REPLACE(p.["product_category_name"], '"', '')
        )
)

SELECT
    category_name,
    ROUND(total_sales, 2) AS total_sales,
    ROUND(average_rating, 2) AS average_rating -- Will show as NULL
FROM category_analysis
WHERE
    total_sales > (SELECT AVG(total_sales) FROM category_analysis)
ORDER BY
    total_sales DESC;






/*====================================================================
 ADDITIONAL ANALYSIS
 OVERALL AVERAGE CUSTOMER RATING
 ====================================================================*/


SELECT

    ROUND(

        AVG(

            TRY_CONVERT(
                FLOAT,
                ["review_score"]
            )

        ),

        2

    ) AS average_review_score

FROM dbo.olist_order_reviews_dataset;


/*====================================================================
 DATA QUALITY CHECKS
 These queries help verify the imported data before final submission.
 ====================================================================*/


/*--------------------------------------------------------------------
 CHECK 1: NULL ORDER IDs
 --------------------------------------------------------------------*/

SELECT
    COUNT(*) AS null_order_ids
FROM dbo.olist_orders_dataset
WHERE ["order_id"] IS NULL;


/*--------------------------------------------------------------------
 CHECK 2: NULL CUSTOMER IDs
 --------------------------------------------------------------------*/

SELECT
    COUNT(*) AS null_customer_ids
FROM dbo.olist_orders_dataset
WHERE ["customer_id"] IS NULL;


/*--------------------------------------------------------------------
 CHECK 3: INVALID PAYMENT VALUES
 --------------------------------------------------------------------*/

SELECT
    COUNT(*) AS invalid_payment_values
FROM dbo.olist_order_payments_dataset
WHERE
    TRY_CONVERT(
        DECIMAL(18,2),
        ["payment_value"]
    ) IS NULL;



/*--------------------------------------------------------------------
 CHECK 4: ORDER STATUS COUNTS
 --------------------------------------------------------------------*/

SELECT

    ["order_status"] AS order_status,

    COUNT(*) AS order_count

FROM dbo.olist_orders_dataset

GROUP BY
    ["order_status"]

ORDER BY
    order_count DESC;


/*--------------------------------------------------------------------
 CHECK 5: DATE CONVERSION CHECK
 --------------------------------------------------------------------*/

SELECT TOP 20

    ["order_purchase_timestamp"] AS original_purchase_date,

    TRY_CONVERT(
        DATETIME,
        ["order_purchase_timestamp"]
    ) AS converted_purchase_date

FROM dbo.olist_orders_dataset;


/*====================================================================
 ADVANCED SQL - RANKING
 Rank states by revenue.

 Demonstrates:
    - CTE
    - GROUP BY
    - SUM
    - RANK()
    - Window function
 ====================================================================*/


WITH state_sales AS
(
    SELECT

        c.["customer_state"] AS customer_state,

        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ) AS total_revenue

    FROM dbo.olist_customers_dataset AS c

    INNER JOIN dbo.olist_orders_dataset AS o
        ON c.["customer_id"] = o.["customer_id"]

    INNER JOIN dbo.olist_order_payments_dataset AS p
        ON o.["order_id"] = p.["order_id"]

    GROUP BY
        c.["customer_state"]
)

SELECT

    customer_state,

    ROUND(
        total_revenue,
        2
    ) AS total_revenue,

    RANK() OVER
    (
        ORDER BY
            total_revenue DESC
    ) AS revenue_rank

FROM state_sales

ORDER BY
    revenue_rank;


/*====================================================================
 ADVANCED SQL - TOP CUSTOMERS WITH RANKING
 ====================================================================*/


WITH customer_sales AS
(
    SELECT

        c.["customer_unique_id"] AS customer_unique_id,

        COUNT(
            DISTINCT o.["order_id"]
        ) AS total_orders,

        SUM(
            TRY_CONVERT(
                DECIMAL(18,2),
                p.["payment_value"]
            )
        ) AS total_spending

    FROM dbo.olist_customers_dataset AS c

    INNER JOIN dbo.olist_orders_dataset AS o
        ON c.["customer_id"] = o.["customer_id"]

    INNER JOIN dbo.olist_order_payments_dataset AS p
        ON o.["order_id"] = p.["order_id"]

    GROUP BY
        c.["customer_unique_id"]
)

SELECT

    customer_unique_id,

    total_orders,

    ROUND(
        total_spending,
        2
    ) AS total_spending,

    RANK() OVER
    (
        ORDER BY
            total_spending DESC
    ) AS customer_rank

FROM customer_sales

ORDER BY
    customer_rank;


/*====================================================================
 FINAL PROJECT KPI SUMMARY

 This produces a compact summary for the README / presentation.
 ====================================================================*/


SELECT

    /* Total Orders */
    (
        SELECT
            COUNT(DISTINCT ["order_id"])
        FROM dbo.olist_orders_dataset
    ) AS total_orders,

    /* Total Revenue */
    (
        SELECT
            ROUND(
                SUM(
                    TRY_CONVERT(
                        DECIMAL(18,2),
                        ["payment_value"]
                    )
                ),
                2
            )
        FROM dbo.olist_order_payments_dataset
    ) AS total_revenue,

    /* Average Order Value */
    (
        SELECT
            ROUND(
                AVG(order_value),
                2
            )
        FROM
        (
            SELECT

                ["order_id"] AS order_id,

                SUM(
                    TRY_CONVERT(
                        DECIMAL(18,2),
                        ["payment_value"]
                    )
                ) AS order_value

            FROM dbo.olist_order_payments_dataset

            GROUP BY
                ["order_id"]

        ) AS order_summary
    ) AS average_order_value,

    /* Average Review Score */
    (
        SELECT
            ROUND(
                AVG(
                    TRY_CONVERT(
                        FLOAT,
                        ["review_score"]
                    )
                ),
                2
            )
        FROM dbo.olist_order_reviews_dataset
    ) AS average_review_score;


/*====================================================================
 END OF PROJECT 01 SQL SCRIPT
 ====================================================================*/