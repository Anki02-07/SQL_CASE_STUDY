/* ================================================================
   PROJECT 2
   RETAIL SALES & PRODUCT PERFORMANCE ANALYSIS
   DATABASE: ADVENTUREWORKS
   PLATFORM: MICROSOFT SQL SERVER

   Description:
   This project analyzes sales performance, products, customers,
   territories and salespersons using the AdventureWorks database.

   ================================================================ */


/* ================================================================
   SECTION 1: DATABASE SETUP
   ================================================================ */

USE AdventureWorks2012;
GO


/* ================================================================
   SECTION 2: DATABASE & TABLE EXPLORATION
   ================================================================ */

/* Display current database */
SELECT DB_NAME() AS Current_Database;
GO

/* Display all base tables */
SELECT
    TABLE_SCHEMA,
    TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_SCHEMA, TABLE_NAME;
GO

/* Check Sales Order Header */
SELECT TOP 10 *
FROM Sales.SalesOrderHeader;
GO

/* Check Sales Order Detail */
SELECT TOP 10 *
FROM Sales.SalesOrderDetail;
GO

/* Check Product table */
SELECT TOP 10 *
FROM Production.Product;
GO

/* Check Product Subcategory */
SELECT TOP 10 *
FROM Production.ProductSubcategory;
GO

/* Check Product Category */
SELECT TOP 10 *
FROM Production.ProductCategory;
GO

/* Check Customer table */
SELECT TOP 10 *
FROM Sales.Customer;
GO

/* Check Sales Territory */
SELECT TOP 10 *
FROM Sales.SalesTerritory;
GO

/* Check Sales Person */
SELECT TOP 10 *
FROM Sales.SalesPerson;
GO


/* ================================================================
   SECTION 3: RECORD COUNTS
   ================================================================ */

SELECT
    'SalesOrderHeader' AS Table_Name,
    COUNT(*) AS Record_Count
FROM Sales.SalesOrderHeader

UNION ALL

SELECT
    'SalesOrderDetail',
    COUNT(*)
FROM Sales.SalesOrderDetail

UNION ALL

SELECT
    'Product',
    COUNT(*)
FROM Production.Product

UNION ALL

SELECT
    'Customer',
    COUNT(*)
FROM Sales.Customer

UNION ALL

SELECT
    'SalesTerritory',
    COUNT(*)
FROM Sales.SalesTerritory;
GO


/* ================================================================
   SECTION 4: SALES DATE RANGE
   ================================================================ */

SELECT
    MIN(OrderDate) AS First_Order_Date,
    MAX(OrderDate) AS Last_Order_Date
FROM Sales.SalesOrderHeader;
GO


/* ================================================================
   Q1. TOTAL REVENUE
   ================================================================ */

SELECT
    ROUND(SUM(TotalDue), 2) AS Total_Revenue
FROM Sales.SalesOrderHeader;
GO


/* ================================================================
   Q2. TOTAL NUMBER OF ORDERS
   ================================================================ */

SELECT
    COUNT(DISTINCT SalesOrderID) AS Total_Orders
FROM Sales.SalesOrderHeader;
GO


/* ================================================================
   Q3. TOTAL QUANTITY SOLD
   ================================================================ */

SELECT
    SUM(OrderQty) AS Total_Quantity_Sold
FROM Sales.SalesOrderDetail;
GO


/* ================================================================
   Q4. AVERAGE ORDER VALUE
   ================================================================ */

SELECT
    ROUND(AVG(TotalDue), 2) AS Average_Order_Value
FROM Sales.SalesOrderHeader;
GO


/* ================================================================
   Q5. YEAR-WISE REVENUE
   ================================================================ */

SELECT
    YEAR(OrderDate) AS Sales_Year,
    ROUND(SUM(TotalDue), 2) AS Total_Revenue
FROM Sales.SalesOrderHeader
GROUP BY YEAR(OrderDate)
ORDER BY Sales_Year;
GO


/* ================================================================
   Q6. MONTH-WISE REVENUE
   ================================================================ */

SELECT
    YEAR(OrderDate) AS Sales_Year,
    MONTH(OrderDate) AS Month_Number,
    DATENAME(MONTH, OrderDate) AS Month_Name,
    ROUND(SUM(TotalDue), 2) AS Total_Revenue
FROM Sales.SalesOrderHeader
GROUP BY
    YEAR(OrderDate),
    MONTH(OrderDate),
    DATENAME(MONTH, OrderDate)
ORDER BY
    Sales_Year,
    Month_Number;
GO


/* ================================================================
   Q7. TOP 10 PRODUCTS BY REVENUE
   ================================================================ */

SELECT TOP 10
    p.ProductID,
    p.Name AS Product_Name,
    ROUND(SUM(sod.LineTotal), 2) AS Total_Revenue
FROM Sales.SalesOrderDetail sod
INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID
GROUP BY
    p.ProductID,
    p.Name
ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q8. TOP 10 PRODUCTS BY QUANTITY SOLD
   ================================================================ */

SELECT TOP 10
    p.ProductID,
    p.Name AS Product_Name,
    SUM(sod.OrderQty) AS Total_Quantity_Sold
FROM Sales.SalesOrderDetail sod
INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID
GROUP BY
    p.ProductID,
    p.Name
ORDER BY
    Total_Quantity_Sold DESC;
GO


/* ================================================================
   Q9. REVENUE BY PRODUCT CATEGORY
   ================================================================ */

SELECT
    pc.ProductCategoryID,
    pc.Name AS Category_Name,
    ROUND(SUM(sod.LineTotal), 2) AS Total_Revenue
FROM Sales.SalesOrderDetail sod

INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID

INNER JOIN Production.ProductSubcategory psc
    ON p.ProductSubcategoryID = psc.ProductSubcategoryID

INNER JOIN Production.ProductCategory pc
    ON psc.ProductCategoryID = pc.ProductCategoryID

GROUP BY
    pc.ProductCategoryID,
    pc.Name

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q10. REVENUE BY PRODUCT SUBCATEGORY
   ================================================================ */

SELECT
    psc.ProductSubcategoryID,
    psc.Name AS Subcategory_Name,
    ROUND(SUM(sod.LineTotal), 2) AS Total_Revenue
FROM Sales.SalesOrderDetail sod

INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID

INNER JOIN Production.ProductSubcategory psc
    ON p.ProductSubcategoryID = psc.ProductSubcategoryID

GROUP BY
    psc.ProductSubcategoryID,
    psc.Name

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q11. REVENUE BY TERRITORY
   ================================================================ */

SELECT
    st.TerritoryID,
    st.Name AS Territory_Name,
    st.CountryRegionCode,
    st.[Group] AS Territory_Group,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue
FROM Sales.SalesOrderHeader soh

INNER JOIN Sales.SalesTerritory st
    ON soh.TerritoryID = st.TerritoryID

GROUP BY
    st.TerritoryID,
    st.Name,
    st.CountryRegionCode,
    st.[Group]

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q12. SALES BY COUNTRY / TERRITORY GROUP
   ================================================================ */

SELECT
    st.CountryRegionCode,
    st.[Group] AS Territory_Group,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue,
    COUNT(DISTINCT soh.SalesOrderID) AS Total_Orders
FROM Sales.SalesOrderHeader soh

INNER JOIN Sales.SalesTerritory st
    ON soh.TerritoryID = st.TerritoryID

GROUP BY
    st.CountryRegionCode,
    st.[Group]

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q13. SALESPERSON PERFORMANCE
   ================================================================ */

SELECT
    sp.BusinessEntityID AS SalesPerson_ID,
    CONCAT(p.FirstName, ' ', p.LastName) AS SalesPerson_Name,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue,
    COUNT(DISTINCT soh.SalesOrderID) AS Total_Orders
FROM Sales.SalesOrderHeader soh

INNER JOIN Sales.SalesPerson sp
    ON soh.SalesPersonID = sp.BusinessEntityID

INNER JOIN Person.Person p
    ON sp.BusinessEntityID = p.BusinessEntityID

GROUP BY
    sp.BusinessEntityID,
    p.FirstName,
    p.LastName

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q14. CUSTOMER-WISE SALES
   ================================================================ */

SELECT
    c.CustomerID,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue,
    COUNT(DISTINCT soh.SalesOrderID) AS Total_Orders
FROM Sales.Customer c

INNER JOIN Sales.SalesOrderHeader soh
    ON c.CustomerID = soh.CustomerID

GROUP BY
    c.CustomerID

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q15. TOP 10 CUSTOMERS BY REVENUE
   ================================================================ */

SELECT TOP 10
    c.CustomerID,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue,
    COUNT(DISTINCT soh.SalesOrderID) AS Total_Orders
FROM Sales.Customer c

INNER JOIN Sales.SalesOrderHeader soh
    ON c.CustomerID = soh.CustomerID

GROUP BY
    c.CustomerID

ORDER BY
    Total_Revenue DESC;
GO


/* ================================================================
   Q16. CUSTOMERS WITH MULTIPLE ORDERS
   ================================================================ */

SELECT
    c.CustomerID,
    COUNT(DISTINCT soh.SalesOrderID) AS Number_of_Orders,
    ROUND(SUM(soh.TotalDue), 2) AS Total_Revenue
FROM Sales.Customer c

INNER JOIN Sales.SalesOrderHeader soh
    ON c.CustomerID = soh.CustomerID

GROUP BY
    c.CustomerID

HAVING COUNT(DISTINCT soh.SalesOrderID) > 1

ORDER BY
    Number_of_Orders DESC;
GO


/* ================================================================
   Q17. REPEAT CUSTOMER COUNT
   ================================================================ */

SELECT
    COUNT(*) AS Repeat_Customer_Count
FROM
(
    SELECT
        CustomerID
    FROM Sales.SalesOrderHeader
    GROUP BY CustomerID
    HAVING COUNT(DISTINCT SalesOrderID) > 1
) AS RepeatCustomers;
GO


/* ================================================================
   Q18. CUSTOMER AVERAGE ORDER VALUE
   ================================================================ */

SELECT
    CustomerID,
    ROUND(AVG(TotalDue), 2) AS Average_Order_Value
FROM Sales.SalesOrderHeader
GROUP BY CustomerID
ORDER BY Average_Order_Value DESC;
GO


/* ================================================================
   Q19. TOP 10 PRODUCTS BY REVENUE USING RANK()
   ================================================================ */

WITH ProductRevenue AS
(
    SELECT
        p.ProductID,
        p.Name AS Product_Name,
        SUM(sod.LineTotal) AS Total_Revenue
    FROM Sales.SalesOrderDetail sod

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    GROUP BY
        p.ProductID,
        p.Name
),

RankedProducts AS
(
    SELECT
        ProductID,
        Product_Name,
        Total_Revenue,
        RANK() OVER (
            ORDER BY Total_Revenue DESC
        ) AS Revenue_Rank
    FROM ProductRevenue
)

SELECT
    ProductID,
    Product_Name,
    ROUND(Total_Revenue, 2) AS Total_Revenue,
    Revenue_Rank
FROM RankedProducts
WHERE Revenue_Rank <= 10
ORDER BY Revenue_Rank;
GO


/* ================================================================
   Q20. PRODUCT RANKING WITH DENSE_RANK()
   ================================================================ */

SELECT
    p.ProductID,
    p.Name AS Product_Name,
    ROUND(SUM(sod.LineTotal), 2) AS Total_Revenue,

    DENSE_RANK() OVER
    (
        ORDER BY SUM(sod.LineTotal) DESC
    ) AS Revenue_Rank

FROM Sales.SalesOrderDetail sod

INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID

GROUP BY
    p.ProductID,
    p.Name

ORDER BY
    Revenue_Rank;
GO


/* ================================================================
   Q21. YEAR-WISE CATEGORY REVENUE
   ================================================================ */

SELECT
    YEAR(soh.OrderDate) AS Sales_Year,
    pc.Name AS Category_Name,
    ROUND(SUM(sod.LineTotal), 2) AS Total_Revenue
FROM Sales.SalesOrderHeader soh

INNER JOIN Sales.SalesOrderDetail sod
    ON soh.SalesOrderID = sod.SalesOrderID

INNER JOIN Production.Product p
    ON sod.ProductID = p.ProductID

INNER JOIN Production.ProductSubcategory psc
    ON p.ProductSubcategoryID = psc.ProductSubcategoryID

INNER JOIN Production.ProductCategory pc
    ON psc.ProductCategoryID = pc.ProductCategoryID

GROUP BY
    YEAR(soh.OrderDate),
    pc.Name

ORDER BY
    Sales_Year,
    Total_Revenue DESC;
GO


/* ================================================================
   Q22. YEAR-WISE CATEGORY RANKING
   ================================================================ */

WITH CategorySales AS
(
    SELECT
        YEAR(soh.OrderDate) AS Sales_Year,
        pc.Name AS Category_Name,
        SUM(sod.LineTotal) AS Total_Revenue
    FROM Sales.SalesOrderHeader soh

    INNER JOIN Sales.SalesOrderDetail sod
        ON soh.SalesOrderID = sod.SalesOrderID

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    INNER JOIN Production.ProductSubcategory psc
        ON p.ProductSubcategoryID = psc.ProductSubcategoryID

    INNER JOIN Production.ProductCategory pc
        ON psc.ProductCategoryID = pc.ProductCategoryID

    GROUP BY
        YEAR(soh.OrderDate),
        pc.Name
)

SELECT
    Sales_Year,
    Category_Name,
    ROUND(Total_Revenue, 2) AS Total_Revenue,

    RANK() OVER
    (
        PARTITION BY Sales_Year
        ORDER BY Total_Revenue DESC
    ) AS Category_Rank

FROM CategorySales

ORDER BY
    Sales_Year,
    Category_Rank;
GO


/* ================================================================
   Q23. PRODUCT REVENUE PERCENTAGE OF TOTAL REVENUE
   ================================================================ */

WITH ProductSales AS
(
    SELECT
        p.ProductID,
        p.Name AS Product_Name,
        SUM(sod.LineTotal) AS Product_Revenue
    FROM Sales.SalesOrderDetail sod

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    GROUP BY
        p.ProductID,
        p.Name
)

SELECT
    ProductID,
    Product_Name,
    ROUND(Product_Revenue, 2) AS Product_Revenue,

    ROUND(
        Product_Revenue * 100.0 /
        SUM(Product_Revenue) OVER (),
        2
    ) AS Revenue_Percentage

FROM ProductSales

ORDER BY
    Product_Revenue DESC;
GO


/* ================================================================
   Q24. TOP 10 PRODUCTS AND THEIR REVENUE CONTRIBUTION
   ================================================================ */

WITH ProductSales AS
(
    SELECT
        p.ProductID,
        p.Name AS Product_Name,
        SUM(sod.LineTotal) AS Product_Revenue
    FROM Sales.SalesOrderDetail sod

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    GROUP BY
        p.ProductID,
        p.Name
),

RankedProducts AS
(
    SELECT
        *,
        RANK() OVER
        (
            ORDER BY Product_Revenue DESC
        ) AS Product_Rank
    FROM ProductSales
)

SELECT
    ProductID,
    Product_Name,
    ROUND(Product_Revenue, 2) AS Product_Revenue,

    ROUND(
        Product_Revenue * 100.0 /
        SUM(Product_Revenue) OVER (),
        2
    ) AS Revenue_Percentage,

    Product_Rank

FROM RankedProducts

WHERE Product_Rank <= 10

ORDER BY
    Product_Rank;
GO


/* ================================================================
   Q25. MONTHLY SALES TREND
   ================================================================ */

SELECT
    YEAR(OrderDate) AS Sales_Year,
    MONTH(OrderDate) AS Sales_Month,
    ROUND(SUM(TotalDue), 2) AS Monthly_Revenue
FROM Sales.SalesOrderHeader
GROUP BY
    YEAR(OrderDate),
    MONTH(OrderDate)
ORDER BY
    Sales_Year,
    Sales_Month;
GO


/* ================================================================
   Q26. MONTH-OVER-MONTH REVENUE USING LAG()
   ================================================================ */

WITH MonthlySales AS
(
    SELECT
        YEAR(OrderDate) AS Sales_Year,
        MONTH(OrderDate) AS Sales_Month,
        SUM(TotalDue) AS Monthly_Revenue
    FROM Sales.SalesOrderHeader
    GROUP BY
        YEAR(OrderDate),
        MONTH(OrderDate)
)

SELECT
    Sales_Year,
    Sales_Month,
    ROUND(Monthly_Revenue, 2) AS Monthly_Revenue,

    ROUND(
        LAG(Monthly_Revenue) OVER
        (
            ORDER BY Sales_Year, Sales_Month
        ),
        2
    ) AS Previous_Month_Revenue,

    ROUND(
        Monthly_Revenue -
        LAG(Monthly_Revenue) OVER
        (
            ORDER BY Sales_Year, Sales_Month
        ),
        2
    ) AS Revenue_Change

FROM MonthlySales

ORDER BY
    Sales_Year,
    Sales_Month;
GO


/* ================================================================
   Q27. PRODUCT SALES BY YEAR
   ================================================================ */


/* ================================================================
   Q34. AVERAGE ORDER VALUE BY TERRITORY
   ================================================================ */

SELECT
    st.Name AS Territory_Name,

    COUNT(DISTINCT soh.SalesOrderID) AS Total_Orders,

    ROUND(
        AVG(soh.TotalDue),
        2
    ) AS Average_Order_Value,

    ROUND(
        SUM(soh.TotalDue),
        2
    ) AS Total_Revenue

FROM Sales.SalesOrderHeader soh

INNER JOIN Sales.SalesTerritory st
    ON soh.TerritoryID = st.TerritoryID

GROUP BY
    st.Name

ORDER BY
    Average_Order_Value DESC;
GO


/* ================================================================
   Q35. SALESPERSON REVENUE RANKING
   ================================================================ */

WITH SalesPersonRevenue AS
(
    SELECT
        sp.BusinessEntityID AS SalesPerson_ID,
        CONCAT(p.FirstName, ' ', p.LastName) AS SalesPerson_Name,
        SUM(soh.TotalDue) AS Revenue

    FROM Sales.SalesOrderHeader soh

    INNER JOIN Sales.SalesPerson sp
        ON soh.SalesPersonID = sp.BusinessEntityID

    INNER JOIN Person.Person p
        ON sp.BusinessEntityID = p.BusinessEntityID

    GROUP BY
        sp.BusinessEntityID,
        p.FirstName,
        p.LastName
)

SELECT
    SalesPerson_ID,
    SalesPerson_Name,
    ROUND(Revenue, 2) AS Revenue,

    RANK() OVER
    (
        ORDER BY Revenue DESC
    ) AS Revenue_Rank

FROM SalesPersonRevenue

ORDER BY
    Revenue_Rank;
GO


/* ================================================================
   Q36. CATEGORY REVENUE USING CTE
   ================================================================ */

WITH CategoryRevenue AS
(
    SELECT
        pc.ProductCategoryID,
        pc.Name AS Category_Name,
        SUM(sod.LineTotal) AS Revenue

    FROM Sales.SalesOrderDetail sod

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    INNER JOIN Production.ProductSubcategory psc
        ON p.ProductSubcategoryID = psc.ProductSubcategoryID

    INNER JOIN Production.ProductCategory pc
        ON psc.ProductCategoryID = pc.ProductCategoryID

    GROUP BY
        pc.ProductCategoryID,
        pc.Name
)

SELECT
    ProductCategoryID,
    Category_Name,
    ROUND(Revenue, 2) AS Revenue

FROM CategoryRevenue

ORDER BY
    Revenue DESC;
GO


/* ================================================================
   Q37. PRODUCTS WITH REVENUE ABOVE AVERAGE PRODUCT REVENUE
   ================================================================ */

WITH ProductRevenue AS
(
    SELECT
        p.ProductID,
        p.Name AS Product_Name,
        SUM(sod.LineTotal) AS Revenue

    FROM Sales.SalesOrderDetail sod

    INNER JOIN Production.Product p
        ON sod.ProductID = p.ProductID

    GROUP BY
        p.ProductID,
        p.Name
)

SELECT
    ProductID,
    Product_Name,
    ROUND(Revenue, 2) AS Revenue

FROM ProductRevenue

WHERE Revenue >
(
    SELECT AVG(Revenue)
    FROM ProductRevenue
)

ORDER BY
    Revenue DESC;
GO


/* ================================================================
   Q38. CUSTOMERS ABOVE AVERAGE CUSTOMER REVENUE
   ================================================================ */

WITH CustomerRevenue AS
(
    SELECT
        CustomerID,
        SUM(TotalDue) AS Revenue

    FROM Sales.SalesOrderHeader

    WHERE CustomerID IS NOT NULL

    GROUP BY
        CustomerID
)

SELECT
    CustomerID,
    ROUND(Revenue, 2) AS Revenue

FROM CustomerRevenue

WHERE Revenue >
(
    SELECT AVG(Revenue)
    FROM CustomerRevenue
)

ORDER BY
    Revenue DESC;
GO


/* ================================================================
   Q39. CUSTOMER RANKING BY REVENUE
   ================================================================ */

WITH CustomerRevenue AS
(
    SELECT
        CustomerID,
        SUM(TotalDue) AS Revenue

    FROM Sales.SalesOrderHeader

    WHERE CustomerID IS NOT NULL

    GROUP BY
        CustomerID
)

SELECT
    CustomerID,
    ROUND(Revenue, 2) AS Revenue,

    RANK() OVER
    (
        ORDER BY Revenue DESC
    ) AS Customer_Rank

FROM CustomerRevenue

ORDER BY
    Customer_Rank;
GO


/* ================================================================
   Q40. FINAL PROJECT SUMMARY
   ================================================================ */

SELECT
    COUNT(DISTINCT SalesOrderID) AS Total_Orders,
    ROUND(SUM(TotalDue), 2) AS Total_Revenue,
    ROUND(AVG(TotalDue), 2) AS Average_Order_Value
FROM Sales.SalesOrderHeader;
GO


/* ================================================================
   END OF PROJECT 2
   RETAIL SALES & PRODUCT PERFORMANCE ANALYSIS
   ================================================================ */