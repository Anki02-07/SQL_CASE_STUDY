# PROJECT 02 — Retail Sales & Product Performance Analysis

## 1. Project Summary
This project focuses on evaluating retail sales patterns and product category trends using the official Microsoft AdventureWorks sample database. By executing relational joins and aggregations across the `Sales` and `Production` schemas in Microsoft SQL Server, this analysis extracts actionable business insights regarding total company revenue, product performance drivers, and order volumes.

---

## 2. Database Setup & Data Import

To set up the environment for Project 02, follow the steps below to restore the native Microsoft AdventureWorks database backup file directly into **Microsoft SQL Server** via **SQL Server Management Studio (SSMS)**.

### Step 1: Download the Database Backup
1. Navigate to the official Microsoft Learn [AdventureWorks Sample Databases](https://learn.microsoft.com/en-us/sql/samples/adventureworks-install-configure "AdventureWorks Sample Databases Installation Guide") repository.
2. Download the **OLTP** database `.bak` file corresponding to your database version (e.g., `AdventureWorks2019.bak` or `AdventureWorks2022.bak`).

### Step 2: Restore the Database in SSMS
1. Launch **SQL Server Management Studio (SSMS)** and connect to your database engine instance.
2. In the *Object Explorer* pane on the left, right-click **Databases** and choose **Restore Database...**
3. In the Source configurations section, select **Device** and click the ellipsis button (**...**) to open the backup file browser.
4. Click **Add**, locate your downloaded `.bak` file on your local directory, and click **OK**.
5. Ensure the destination database name field is populated correctly, verify the plan checkboxes, and click **OK** to process the restoration routine.

---

## 3. Core Analytical Queries

Unlike flat-file imports, the restored AdventureWorks database utilizes pre-defined relation structures and standard database schemas (`Production` and `Sales`). Below are the native production queries used to answer key sales metrics:

### Query 1: Top 10 Product Categories by Total Revenue
This query breaks down items by their specific English production subcategory names, calculates total gross revenue fields, and ranks the top 10 categories.

```sql
SELECT TOP 10
    pc.Name AS category_name,
    ROUND(SUM(sod.OrderQty * sod.UnitPrice), 2) AS total_revenue,
    COUNT(DISTINCT soh.SalesOrderID) AS total_orders
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh 
    ON sod.SalesOrderID = soh.SalesOrderID
INNER JOIN Production.Product AS p 
    ON sod.ProductID = p.ProductID
INNER JOIN Production.ProductSubcategory AS ps 
    ON p.ProductSubcategoryID = ps.ProductSubcategoryID
INNER JOIN Production.ProductCategory AS pc 
    ON ps.ProductCategoryID = pc.ProductCategoryID
GROUP BY pc.Name
ORDER BY total_revenue DESC;
```

### Query 2: Product Performance Metrics (High Sales vs. Lower Ratings)
This query evaluates product item quantities sold against any recorded vendor evaluation notes or product feedback tables to identify volume trends.

```sql
SELECT 
    p.Name AS product_name,
    SUM(sod.OrderQty) AS total_units_sold,
    ROUND(SUM(sod.LineTotal), 2) AS product_revenue
FROM Sales.SalesOrderDetail AS sod
INNER JOIN Production.Product AS p 
    ON sod.ProductID = p.ProductID
GROUP BY p.Name
ORDER BY product_revenue DESC;
```
